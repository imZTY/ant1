define({
  "name": "ProductShow - Ant Design Pro",
  "version": "0.2.1",
  "description": "The back font API doc",
  "title": "AntProject API",
  "url": "https://zengtianyi.top/ant1",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-03-10T05:54:01.218Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
